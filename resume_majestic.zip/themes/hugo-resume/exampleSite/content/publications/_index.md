---
title: Publications
date: 2020-01-07T16:47:30.077Z
link: NA
image: /img/organicdevops.webp
description: NA
weight: 10
sitemap:
  priority: 0.6
  weight: 0.5
---
<!--

This page represents the landing page for "publications" section. It is also shown under the homepage header for "publications". It should be therefore relatively short and sweet.

\-->

A collection of articles, presentations or talks, most likely on Culture and DevOps, because let's admit it, they are one in the same ;)
