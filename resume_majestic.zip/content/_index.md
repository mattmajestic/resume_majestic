---
date: "2018-02-10T18:56:13-05:00"
outputs:
- html
- rss
- json
sitemap:
  priority: 1
title: Home
---
Proven Software Platform Engineer with experience leveraging agile, DevOps, and CI/CD to manage large scale distributed platforms both on prem and in public cloud.
