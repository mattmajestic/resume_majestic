---
date: "2020-02-11T12:41:05-05:00"
description: R Shiny app to predict revenue using Machine Learning for effective pricing to current and future merchants.
fact: ""
featured: true
image: /img/aafb-agent-ids-match-bamboo.webp
link: https://github.com/mattmajestic
tags:
- DevOps
- R
- R Shiny
- Azure VM
- Linux
- Docker
title: Service Segmentation for Coca Cola Beverages Florida
---

R Shiny app to predict revenue using Machine Learning for effective pricing to current and future merchants.
